from __future__ import annotations

import os
import urllib.parse
import urllib.request

from krita import Extension, InfoObject, Krita
from PyQt5.QtWidgets import QInputDialog, QMessageBox


class KritaDatasetBridgeExtension(Extension):
    def __init__(self, parent):
        super().__init__(parent)

    def setup(self):
        pass

    def createActions(self, window):
        action = window.createAction(
            "send_active_document_to_data_curation_tool",
            "Send Active Document to Data Curation Tool",
            "tools/scripts",
        )
        action.triggered.connect(self.send_active_document)
        mask_action = window.createAction(
            "send_active_document_as_dct_mask",
            "Send Active Document as Data Curation Mask",
            "tools/scripts",
        )
        mask_action.triggered.connect(self.send_active_document_as_mask)

    def _server_url(self):
        url, ok = QInputDialog.getText(None, "Data Curation Tool URL", "Local app URL:", text="http://127.0.0.1:7865")
        if not ok or not url.strip():
            return None
        return url.strip().rstrip("/") + "/"

    def _export_active_png(self, suffix="export"):
        app = Krita.instance()
        doc = app.activeDocument()
        if doc is None:
            QMessageBox.warning(None, "Data Curation Tool", "No active Krita document is open.")
            return None
        tmp_dir = os.path.join(os.path.expanduser("~"), ".data_curation_tool", "krita_bridge")
        os.makedirs(tmp_dir, exist_ok=True)
        safe_name = doc.fileName() or doc.name() or "krita_document.png"
        safe_name = os.path.basename(safe_name)
        base, _ext = os.path.splitext(safe_name)
        export_path = os.path.join(tmp_dir, f"{base or 'krita_document'}_{suffix}.png")
        info = InfoObject()
        doc.exportImage(export_path, info)
        return export_path

    def _multipart_post(self, endpoint, fields, file_field, file_path):
        boundary = "----DCTKritaBoundary7MA4YWxkTrZu0gW"
        body = bytearray()
        for key, value in fields:
            if value is None or str(value).strip() == "":
                continue
            body.extend(f"--{boundary}\r\n".encode())
            body.extend(f'Content-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{file_field}"; filename="{os.path.basename(file_path)}"\r\n'.encode())
        body.extend(b"Content-Type: image/png\r\n\r\n")
        with open(file_path, "rb") as handle:
            body.extend(handle.read())
        body.extend(f"\r\n--{boundary}--\r\n".encode())
        req = urllib.request.Request(endpoint, data=bytes(body), method="POST")
        req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        with urllib.request.urlopen(req, timeout=90) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def send_active_document(self):
        url = self._server_url()
        if not url:
            return
        dataset_id, _ = QInputDialog.getText(None, "Dataset ID", "Dataset ID to import into (optional):", text="")
        tags, _ = QInputDialog.getText(None, "Tags", "Optional comma-separated tags:", text="")
        caption, _ = QInputDialog.getMultiLineText(None, "Caption", "Optional caption:", text="")
        export_path = self._export_active_png("export")
        if not export_path:
            return
        endpoint = urllib.parse.urljoin(url, "api/krita/import-image")
        try:
            text = self._multipart_post(endpoint, [("dataset_id", dataset_id), ("tags", tags), ("caption", caption)], "file", export_path)
            QMessageBox.information(None, "Data Curation Tool", f"Image sent.\n\n{text[:1000]}")
        except Exception as exc:
            QMessageBox.critical(None, "Data Curation Tool", f"Could not send image:\n{exc}")

    def send_active_document_as_mask(self):
        url = self._server_url()
        if not url:
            return
        media_id, ok = QInputDialog.getText(None, "Media ID", "Data Curation Tool media_id to attach this mask to:", text="")
        if not ok or not media_id.strip():
            return
        label, _ = QInputDialog.getText(None, "Mask label", "Label / class name:", text="object")
        target_name, _ = QInputDialog.getText(None, "Target name", "Optional target / character name:", text="")
        export_path = self._export_active_png("mask")
        if not export_path:
            return
        endpoint = urllib.parse.urljoin(url, "api/krita/import-mask")
        try:
            text = self._multipart_post(endpoint, [("media_id", media_id), ("label", label), ("target_name", target_name), ("set_name", "krita")], "file", export_path)
            QMessageBox.information(None, "Data Curation Tool", f"Mask sent.\n\n{text[:1000]}")
        except Exception as exc:
            QMessageBox.critical(None, "Data Curation Tool", f"Could not send mask:\n{exc}")
