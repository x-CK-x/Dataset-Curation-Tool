# Krita Dataset Bridge

Optional Krita Python plugin for sending the active document back to the local Data Curation Tool.

Install by copying `krita_dataset_bridge.desktop` and the `krita_dataset_bridge/` folder into Krita's Python plugin directory, then enable **Dataset Bridge** in Krita's Python Plugin Manager.

Actions added under **Tools > Scripts**:

- **Send Active Document to Data Curation Tool** posts a PNG to `/api/krita/import-image` with optional tags, caption, and dataset id.
- **Send Active Document as Data Curation Mask** posts a PNG mask to `/api/krita/import-mask` with media id, label, and optional target name.

The app also exports annotation handoff packages with `krita_annotation_package.json` manifests and copied mask files.
